import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/unsplash.dart';
// import 'package:myapp/page-1/assets.dart';
// import 'package:myapp/page-1/signup-11.dart';
// import 'package:myapp/page-1/login.dart';
// import 'package:myapp/page-1/login-h.dart';
// import 'package:myapp/page-1/signup-type.dart';
// import 'package:myapp/page-1/login-type.dart';
// import 'package:myapp/page-1/signup-12.dart';
// import 'package:myapp/page-1/home.dart';
// import 'package:myapp/page-1/iphone-13-pro.dart';
// import 'package:myapp/page-1/admin.dart';
// import 'package:myapp/page-1/admin2.dart';
// import 'package:myapp/page-1/user-notification.dart';
// import 'package:myapp/page-1/user-notification-qhV.dart';
// import 'package:myapp/page-1/admin-notification.dart';
// import 'package:myapp/page-1/user-profile.dart';
// import 'package:myapp/page-1/contact.dart';
// import 'package:myapp/page-1/iphone-13-pro-d6s.dart';
// import 'package:myapp/page-1/iphone-13-pro-m5u.dart';
// import 'package:myapp/page-1/iphone-13-pro-PoR.dart';
// import 'package:myapp/page-1/iphone-13-pro-qYF.dart';
// import 'package:myapp/page-1/iphone-13-pro-Zpw.dart';
// import 'package:myapp/page-1/iphone-13-pro-XFH.dart';
// import 'package:myapp/page-1/iphone-13-pro-Fns.dart';
// import 'package:myapp/page-1/iphone-13-pro-4LK.dart';
// import 'package:myapp/page-1/iphone-13-pro-zaf.dart';
// import 'package:myapp/page-1/iphone-13-pro-WCs.dart';
// import 'package:myapp/page-1/iphone-13-pro-14P.dart';
// import 'package:myapp/page-1/iphone-13-pro-GkK.dart';
// import 'package:myapp/page-1/iphone-13-pro-nZZ.dart';
// import 'package:myapp/page-1/iphone-13-pro-NdZ.dart';
// import 'package:myapp/page-1/iphone-13-pro-egs.dart';
// import 'package:myapp/page-1/iphone-13-pro-Yiw.dart';
// import 'package:myapp/page-1/iphone-13-pro-gNX.dart';
// import 'package:myapp/page-1/iphone-13-pro-FFq.dart';
// import 'package:myapp/page-1/iphone-13-pro-2K5.dart';
// import 'package:myapp/page-1/iphone-13-pro-QVH.dart';
// import 'package:myapp/page-1/iphone-13-pro-y7h.dart';
// import 'package:myapp/page-1/iphone-13-pro-NKV.dart';
// import 'package:myapp/page-1/iphone-13-pro-Wmh.dart';
// import 'package:myapp/page-1/iphone-13-pro-Wps.dart';
// import 'package:myapp/page-1/iphone-13-pro-djh.dart';
// import 'package:myapp/page-1/iphone-13-pro-2gb.dart';
// import 'package:myapp/page-1/iphone-13-pro-rqH.dart';
// import 'package:myapp/page-1/iphone-13-pro-5Ky.dart';
// import 'package:myapp/page-1/iphone-13-pro-LAf.dart';
// import 'package:myapp/page-1/iphone-13-pro-sZD.dart';
// import 'package:myapp/page-1/iphone-13-pro-yYw.dart';
// import 'package:myapp/page-1/iphone-13-pro-XNj.dart';
// import 'package:myapp/page-1/desktop-1.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
