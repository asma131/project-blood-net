import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1054;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // assetsnCb (9:7)
        width: double.infinity,
        height: 1209*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // buttonFM5 (2:118)
              left: 31*fem,
              top: 22*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
                width: 184*fem,
                height: 233*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff9747ff)),
                  borderRadius: BorderRadius.circular(5*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // property1default1jZ (2:97)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                      padding: EdgeInsets.fromLTRB(15*fem, 16*fem, 20.67*fem, 14*fem),
                      width: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xbc488286),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x59000000),
                            offset: Offset(0*fem, 7*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // donatenow9UP (2:90)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.67*fem, 0*fem),
                            child: Text(
                              'Donate Now',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // materialsymbolsarrowrightaltsS (2:91)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                            width: 14.67*fem,
                            height: 11*fem,
                            child: Image.asset(
                              'assets/page-1/images/material-symbols-arrow-right-alt.png',
                              width: 14.67*fem,
                              height: 11*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // property1signupVyV (2:119)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 21*fem),
                      width: double.infinity,
                      height: 50*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2c6367),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x59000000),
                            offset: Offset(0*fem, 7*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          'Signup',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // property1login4fD (2:124)
                      width: double.infinity,
                      height: 51*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x59000000),
                            offset: Offset(0*fem, 7*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          'Login',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // paletteThM (2:19)
              left: 232*fem,
              top: 24*fem,
              child: Container(
                width: 100*fem,
                height: 50*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // GPu (2:15)
                      width: 50*fem,
                      height: 50*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2c6367),
                      ),
                    ),
                    Container(
                      // e40zKu (2:16)
                      width: 50*fem,
                      height: 50*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff373e40),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // inputWJF (10:37)
              left: 232*fem,
              top: 93*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
                width: 333*fem,
                height: 170*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff9747ff)),
                  borderRadius: BorderRadius.circular(5*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // property1default7Yw (10:36)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xffefefef),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: Text(
                            'Full Name',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      // property1focusedrQ3 (10:38)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        child: Center(
                          // rectangle4m1D (10:39)
                          child: SizedBox(
                            width: double.infinity,
                            height: 55*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(10*fem),
                                border: Border.all(color: Color(0xff2c6367)),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // accounttypek83 (18:1528)
              left: 582*fem,
              top: 8*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
                width: 344*fem,
                height: 510*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff9747ff)),
                  borderRadius: BorderRadius.circular(5*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // property1defaulto6K (18:1527)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(58*fem, 17*fem, 58*fem, 16*fem),
                          width: double.infinity,
                          height: 225*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(20*fem),
                          ),
                          child: Container(
                            // accounttypeQro (18:1015)
                            padding: EdgeInsets.fromLTRB(0.08*fem, 0*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // undrawmedicineb1ol1skP (18:1016)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                  width: 187.92*fem,
                                  height: 133*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/undrawmedicineb-1-ol-1-1LF.png',
                                    width: 187.92*fem,
                                    height: 133*fem,
                                  ),
                                ),
                                Container(
                                  // hospitalaccountJUK (18:1182)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.08*fem, 0*fem),
                                  child: Text(
                                    'Hospital Account',
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 17*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xff373e40),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      // property1activexYs (18:1529)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(58*fem, 17*fem, 58*fem, 16*fem),
                        width: double.infinity,
                        height: 225*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff2c6367)),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Container(
                          // accounttypectK (18:1530)
                          padding: EdgeInsets.fromLTRB(0.08*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // undrawmedicineb1ol1UvX (18:1531)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                width: 187.92*fem,
                                height: 133*fem,
                                child: Image.asset(
                                  'assets/page-1/images/undrawmedicineb-1-ol-1-xbM.png',
                                  width: 187.92*fem,
                                  height: 133*fem,
                                ),
                              ),
                              Container(
                                // hospitalaccount3Es (18:1697)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.08*fem, 0*fem),
                                child: Text(
                                  'Hospital Account',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 17*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // donatoraccountJwV (18:2705)
              left: 31*fem,
              top: 282*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
                width: 344*fem,
                height: 478*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff9747ff)),
                  borderRadius: BorderRadius.circular(5*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // property1defaultwjZ (18:2704)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(58*fem, 13.97*fem, 58*fem, 13*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(20*fem),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // undrawpeoplere8spw19aj (15:465)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                                width: 188*fem,
                                height: 133.03*fem,
                                child: Image.asset(
                                  'assets/page-1/images/undrawpeoplere8spw-1-kQb.png',
                                  width: 188*fem,
                                  height: 133.03*fem,
                                ),
                              ),
                              Container(
                                // donatoraccountxo5 (18:2700)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                child: Text(
                                  'Donator Account',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 17*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      // property1activec6w (18:2706)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(58*fem, 13.97*fem, 58*fem, 13*fem),
                        width: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff2c6367)),
                          borderRadius: BorderRadius.circular(20*fem),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // undrawpeoplere8spw1sHm (18:2707)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                              width: 188*fem,
                              height: 133.03*fem,
                              child: Image.asset(
                                'assets/page-1/images/undrawpeoplere8spw-1-K9M.png',
                                width: 188*fem,
                                height: 133.03*fem,
                              ),
                            ),
                            Container(
                              // donatoraccountehq (18:2738)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                              child: Text(
                                'Donator Account',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 17*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // undrawfemaleavatarrel6cx1WV9 (18:3252)
              left: 407*fem,
              top: 580*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
                width: 240*fem,
                height: 460*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff9747ff)),
                  borderRadius: BorderRadius.circular(5*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // property1defaultX9M (18:3251)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 200*fem,
                          height: 200*fem,
                          child: Image.asset(
                            'assets/page-1/images/property-1default-uFZ.png',
                            width: 200*fem,
                            height: 200*fem,
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      // property1activexkT (18:3253)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 200*fem,
                        height: 200*fem,
                        child: Image.asset(
                          'assets/page-1/images/property-1active.png',
                          width: 200*fem,
                          height: 200*fem,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // undrawmaleavatarrey8801yQf (18:3262)
              left: 752*fem,
              top: 551*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 20*fem, 20*fem, 20*fem),
                width: 240*fem,
                height: 460*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff9747ff)),
                  borderRadius: BorderRadius.circular(5*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // property1defaultciX (18:3261)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 200*fem,
                          height: 200*fem,
                          child: Image.asset(
                            'assets/page-1/images/property-1default.png',
                            width: 200*fem,
                            height: 200*fem,
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      // property1activeEzo (18:3263)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 200*fem,
                        height: 200*fem,
                        child: Image.asset(
                          'assets/page-1/images/property-1active-WxB.png',
                          width: 200*fem,
                          height: 200*fem,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}