import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1284;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13pro7K9 (116:1024)
        width: double.infinity,
        height: 872.75*fem,
        child: Stack(
          children: [
            Positioned(
              // iphone13profrontqW3 (116:1011)
              left: 0*fem,
              top: 0.25*fem,
              child: Container(
                width: 826*fem,
                height: 872.5*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadow139 (116:1012)
                      left: 0*fem,
                      top: 854.75*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-4Z9.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bluet6w (116:1013)
                      left: 384*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 427.5*fem,
                          height: 865*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-EeF.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // maskgroupxcb (116:1019)
                      left: 407.787109375*fem,
                      top: 19.7807006836*fem,
                      child: Align(
                        child: SizedBox(
                          width: 381.21*fem,
                          height: 824.94*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group-brT.png',
                            width: 381.21*fem,
                            height: 824.94*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // iphone13probackqwH (116:1020)
              left: 457*fem,
              top: 0*fem,
              child: Container(
                width: 827*fem,
                height: 872.75*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadow8fV (116:1021)
                      left: 0*fem,
                      top: 855*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-HNb.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blue2ks (116:1022)
                      left: 399*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 428*fem,
                          height: 865.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-mb1.png',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}