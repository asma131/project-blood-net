import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // usernotificationkUj (89:287)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // notificationsAYT (89:288)
              left: 79*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 114*fem,
                  height: 28*fem,
                  child: Text(
                    'Notifications',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line8Qhh (89:289)
              left: 40*fem,
              top: 115*fem,
              child: Align(
                child: SizedBox(
                  width: 29.27*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle196qR (89:290)
              left: 40*fem,
              top: 162*fem,
              child: Align(
                child: SizedBox(
                  width: 313*fem,
                  height: 90*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffefefef),
                      borderRadius: BorderRadius.only (
                        bottomRight: Radius.circular(10*fem),
                        bottomLeft: Radius.circular(10*fem),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle20tmH (89:291)
              left: 40*fem,
              top: 282*fem,
              child: Align(
                child: SizedBox(
                  width: 313*fem,
                  height: 90*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffefefef),
                      borderRadius: BorderRadius.only (
                        bottomRight: Radius.circular(10*fem),
                        bottomLeft: Radius.circular(10*fem),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // unsplashamnlyot2zisNK (89:292)
              left: 40*fem,
              top: 162*fem,
              child: Align(
                child: SizedBox(
                  width: 65*fem,
                  height: 90*fem,
                  child: Image.asset(
                    'assets/page-1/images/unsplash-amnlyot2zi-PW3.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // urgentdonationxPm (89:293)
              left: 117*fem,
              top: 175*fem,
              child: Align(
                child: SizedBox(
                  width: 120*fem,
                  height: 22*fem,
                  child: Text(
                    'Urgent Donation',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 16*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // orequest2Pd (89:294)
              left: 117*fem,
              top: 295*fem,
              child: Align(
                child: SizedBox(
                  width: 86*fem,
                  height: 22*fem,
                  child: Text(
                    'O+ Request',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 16*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // unitsofabneededforasurgeryevo (89:295)
              left: 117*fem,
              top: 211*fem,
              child: Align(
                child: SizedBox(
                  width: 184*fem,
                  height: 17*fem,
                  child: Text(
                    '5 Units of AB needed for a surgery ',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // missingoneunitofoKX9 (89:296)
              left: 117*fem,
              top: 331*fem,
              child: Align(
                child: SizedBox(
                  width: 118*fem,
                  height: 17*fem,
                  child: Text(
                    'Missing one unit of O+',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // view8jV (89:297)
              left: 295*fem,
              top: 297*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 17*fem,
                  child: Text(
                    'View',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line15mnT (89:298)
              left: 43.9904785156*fem,
              top: 433*fem,
              child: Align(
                child: SizedBox(
                  width: 106.02*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line14QaX (89:299)
              left: 295*fem,
              top: 313*fem,
              child: Align(
                child: SizedBox(
                  width: 35*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group80Fb9 (89:300)
              left: 295*fem,
              top: 177*fem,
              child: Container(
                width: 42*fem,
                height: 18*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // viewXHm (89:301)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 27*fem,
                          height: 17*fem,
                          child: Text(
                            'View',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // line13C91 (89:302)
                      left: 0*fem,
                      top: 16*fem,
                      child: Align(
                        child: SizedBox(
                          width: 35*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xff2c6367),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // materialsymbolsarrowdropdownro (89:303)
                      left: 31.5*fem,
                      top: 6.2957763672*fem,
                      child: Align(
                        child: SizedBox(
                          width: 3.45*fem,
                          height: 5.41*fem,
                          child: Image.asset(
                            'assets/page-1/images/material-symbols-arrow-drop-down-rounded-Fb9.png',
                            width: 3.45*fem,
                            height: 5.41*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // materialsymbolsarrowdropdownro (89:305)
              left: 326.5*fem,
              top: 303.2956542969*fem,
              child: Align(
                child: SizedBox(
                  width: 3.45*fem,
                  height: 5.41*fem,
                  child: Image.asset(
                    'assets/page-1/images/material-symbols-arrow-drop-down-rounded-rsV.png',
                    width: 3.45*fem,
                    height: 5.41*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // mdisquareroundedbadgeoutlineMJ (89:307)
              left: 206*fem,
              top: 103*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 20*fem,
                  child: Image.asset(
                    'assets/page-1/images/mdi-square-rounded-badge-outline-q4X.png',
                    width: 20*fem,
                    height: 20*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // unsplashdwxetpzjws8kbm (89:309)
              left: 40*fem,
              top: 282*fem,
              child: Align(
                child: SizedBox(
                  width: 65*fem,
                  height: 90*fem,
                  child: Image.asset(
                    'assets/page-1/images/unsplash-dwxetpzjws8.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // mdicheckallqdD (89:310)
              left: 135.2563476562*fem,
              top: 417.4875488281*fem,
              child: Align(
                child: SizedBox(
                  width: 14.53*fem,
                  height: 8.39*fem,
                  child: Image.asset(
                    'assets/page-1/images/mdi-check-all-APD.png',
                    width: 14.53*fem,
                    height: 8.39*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // markallasread51m (89:312)
              left: 44*fem,
              top: 414*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 17*fem,
                  child: Text(
                    'Mark all as read',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle35LyH (89:313)
              left: 244*fem,
              top: 408*fem,
              child: Align(
                child: SizedBox(
                  width: 109*fem,
                  height: 29*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xff2c6367),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // viewallMNb (89:314)
              left: 273*fem,
              top: 413*fem,
              child: Align(
                child: SizedBox(
                  width: 51*fem,
                  height: 18*fem,
                  child: Text(
                    'View All',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle36bw9 (89:315)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 393*fem,
                  height: 852*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xe0373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group81Fko (89:316)
              left: 40*fem,
              top: 288*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(13*fem, 26*fem, 12*fem, 16*fem),
                width: 313*fem,
                height: 213*fem,
                decoration: BoxDecoration (
                  color: Color(0xffefefef),
                  borderRadius: BorderRadius.circular(10*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogrouprhjbrEo (5czYNo9cqRfQ9ifqzzRhJb)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 4*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // abdalihospitalxYj (89:281)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 151*fem, 0*fem),
                            child: Text(
                              'Abdali Hospital',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          TextButton(
                            // mdiclosecircleF23 (89:278)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/mdi-close-circle.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // urgentdonationFw9 (89:282)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 199*fem, 14*fem),
                      child: Text(
                        'Urgent Donation',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w300,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff373e40),
                        ),
                      ),
                    ),
                    Container(
                      // weneednearly5newdonorstocomple (89:280)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 33*fem),
                      constraints: BoxConstraints (
                        maxWidth: 288*fem,
                      ),
                      child: Text(
                        'We need nearly 5 new donors to complete the surgery \nfor a 65 years old woman that has a blood type of AB\nas fast as possible.',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w200,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff373e40),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupvcrzXnB (5czYWi66o27FWwULhgVcRZ)
                      margin: EdgeInsets.fromLTRB(104*fem, 0*fem, 6*fem, 0*fem),
                      width: double.infinity,
                      height: 29*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupeizp3Ej (5czYesXAbzQ9fQ7KB1EizP)
                            margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 25*fem, 5*fem),
                            width: 44*fem,
                            height: double.infinity,
                            child: Text(
                              'Decline',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff2c6367),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupnfjrrhy (5czYmTAY2F15Y1nb6zNFjR)
                            width: 109*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xff2c6367),
                              borderRadius: BorderRadius.circular(5*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                'Accept Request',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 13*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}