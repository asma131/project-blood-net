import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1284;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13proJKD (116:969)
        width: double.infinity,
        height: 872.75*fem,
        child: Stack(
          children: [
            Positioned(
              // iphone13profrontNps (116:956)
              left: 0*fem,
              top: 0.25*fem,
              child: Container(
                width: 826*fem,
                height: 872.5*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowdko (116:957)
                      left: 0*fem,
                      top: 854.75*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-zPd.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blueK7q (116:958)
                      left: 384*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 427.5*fem,
                          height: 865*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-hJK.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // maskgroupoYo (116:964)
                      left: 407.787109375*fem,
                      top: 19.7807617188*fem,
                      child: Align(
                        child: SizedBox(
                          width: 381.21*fem,
                          height: 824.94*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group-3kF.png',
                            width: 381.21*fem,
                            height: 824.94*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // iphone13proback6RR (116:965)
              left: 457*fem,
              top: 0*fem,
              child: Container(
                width: 827*fem,
                height: 872.75*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowoaj (116:966)
                      left: 0*fem,
                      top: 855*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-mGX.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blue7bR (116:967)
                      left: 399*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 428*fem,
                          height: 865.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-UTu.png',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}