import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginfoh (10:69)
        padding: EdgeInsets.fromLTRB(40*fem, 92*fem, 40*fem, 94*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // undrawmedicalcaremovn1KdM (10:87)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 61*fem),
              width: 313*fem,
              height: 232*fem,
              child: Image.asset(
                'assets/page-1/images/undrawmedicalcaremovn-1.png',
                width: 313*fem,
                height: 232*fem,
              ),
            ),
            Container(
              // welcomebackdXZ (10:70)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 30*fem),
              child: Text(
                'Welcome Back',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // inputH6K (10:77)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 31*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Email or user ID',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputS7d (10:78)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 45*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Password',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // button7NB (10:79)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 31*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 293*fem,
                  height: 50*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff2c6367),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x59000000),
                        offset: Offset(0*fem, 7*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Login',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupebkrT4f (5cz6wrrZmXP9YyeQRpeBKR)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // newusersignupwVd (10:75)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 113*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        constraints: BoxConstraints (
                          maxWidth: 75*fem,
                        ),
                        child: RichText(
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                            children: [
                              TextSpan(
                                text: 'New user?',
                              ),
                              TextSpan(
                                text: ' \nSignup',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff2c6367),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  TextButton(
                    // forgotpasswordpLT (126:450)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      ' Forgot password',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff2c6367),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}