import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // usernotificationyVV (89:231)
        padding: EdgeInsets.fromLTRB(40*fem, 99*fem, 40*fem, 415*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupt9lpRcP (5czUQVbhCcatcByERWt9LP)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 127*fem, 35*fem),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // line8sUP (89:236)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 9.73*fem, 0*fem),
                    width: 29.27*fem,
                    height: 2*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                  Container(
                    // notificationsAyH (89:234)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                    child: Text(
                      'Notifications',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // mdisquareroundedbadgeoutlineR8 (89:247)
                    width: 20*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-square-rounded-badge-outline.png',
                      width: 20*fem,
                      height: 20*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9cptHwR (5czUdetS37nkMRKnHV9CpT)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
              width: double.infinity,
              height: 90*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xffefefef)),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(10*fem),
                  bottomLeft: Radius.circular(10*fem),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // unsplashamnlyot2ziVXh (89:238)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                    width: 65*fem,
                    height: 90*fem,
                    child: Image.asset(
                      'assets/page-1/images/unsplash-amnlyot2zi-GZH.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // autogroupzgjdzDZ (5czUppEW4cEDrjzVzPzgjd)
                    margin: EdgeInsets.fromLTRB(0*fem, 13*fem, 0*fem, 24*fem),
                    width: 220*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroup8dufgcB (5czUwPssUrq9jMfmvP8DUf)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                          width: double.infinity,
                          height: 22*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // urgentdonationwo1 (89:239)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 58*fem, 0*fem),
                                child: Text(
                                  'Urgent Donation',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                              Container(
                                // group80ZJb (89:265)
                                margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 2*fem),
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 42*fem,
                                    height: double.infinity,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // viewr2o (89:241)
                                          left: 0*fem,
                                          top: 0*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 27*fem,
                                              height: 17*fem,
                                              child: Text(
                                                'View',
                                                style: SafeGoogleFont (
                                                  'Nunito',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w200,
                                                  height: 1.3625*ffem/fem,
                                                  color: Color(0xff373e40),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line13tEP (89:242)
                                          left: 0*fem,
                                          top: 16*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 35*fem,
                                              height: 1*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff2c6367),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // materialsymbolsarrowdropdownro (89:243)
                                          left: 31.5*fem,
                                          top: 6.2957763672*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 3.45*fem,
                                              height: 5.41*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/material-symbols-arrow-drop-down-rounded-Vwh.png',
                                                width: 3.45*fem,
                                                height: 5.41*fem,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          // unitsofabneededforasurgerybHD (89:240)
                          '5 Units of AB needed for a surgery ',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w200,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupigwf4Rh (5czVUo9DTrmWR13GxWigWf)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
              width: double.infinity,
              height: 90*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xffefefef)),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(10*fem),
                  bottomLeft: Radius.circular(10*fem),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // unsplashdwxetpzjws8GXm (89:257)
                    width: 65*fem,
                    height: 90*fem,
                    child: Image.asset(
                      'assets/page-1/images/unsplash-dwxetpzjws8-xi7.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // autogroupyk99Bej (5czW2XjLahAbUJC5gpYk99)
                    padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 23*fem, 24*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroup1llku4w (5czVihuhrVWWVwuG8P1LLK)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 60*fem, 0*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // orequestwnK (89:251)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                                child: Text(
                                  'O+ Request',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                              Text(
                                // missingoneunitofoxxK (89:252)
                                'Missing one unit of O+',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w200,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff373e40),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupde67gNX (5czVsXzKw8isPi6qz4De67)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.05*fem, 0*fem),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                // viewJPu (89:253)
                                'View',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w200,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff373e40),
                                ),
                              ),
                              Container(
                                // materialsymbolsarrowdropdownro (89:255)
                                margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                width: 3.45*fem,
                                height: 5.41*fem,
                                child: Image.asset(
                                  'assets/page-1/images/material-symbols-arrow-drop-down-rounded-9gf.png',
                                  width: 3.45*fem,
                                  height: 5.41*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupdhcoTw1 (5czWS6tPtZGnP8huwodhCo)
              margin: EdgeInsets.fromLTRB(3.99*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 29*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupcprkmwh (5czWbRxBfxBEqNaTLkCPrK)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 93.99*fem, 3*fem),
                    padding: EdgeInsets.fromLTRB(0.01*fem, 0*fem, 0.01*fem, 0*fem),
                    width: 106.02*fem,
                    height: double.infinity,
                    child: Container(
                      // autogrouprjqpE4b (5czWhLwzpXrhxgh7tNrjQP)
                      width: double.infinity,
                      height: 17*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // markallasreadwjh (89:260)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.26*fem, 0*fem),
                            child: Text(
                              'Mark all as read',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w200,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // mdicheckallQdH (89:258)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.64*fem),
                            width: 14.53*fem,
                            height: 8.39*fem,
                            child: Image.asset(
                              'assets/page-1/images/mdi-check-all.png',
                              width: 14.53*fem,
                              height: 8.39*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // autogroupt2pvhMV (5czWsRVYA4JJke56bDT2PV)
                    width: 109*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                      borderRadius: BorderRadius.circular(5*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        'View All',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}