import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // userprofileL1H (103:245)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupccnpbhu (5czbSi3AybmXVZnjuDcCnP)
              left: 40*fem,
              top: 43*fem,
              child: Container(
                width: 291*fem,
                height: 68*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // group82hF9 (103:249)
                      margin: EdgeInsets.fromLTRB(0*fem, 18*fem, 44*fem, 0*fem),
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(57*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // n1ivw (103:251)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                            width: 50*fem,
                            height: 50*fem,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(57*fem),
                              child: Image.asset(
                                'assets/page-1/images/n-1.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Container(
                            // osamakafaweenQ35 (103:250)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            child: Text(
                              'Osama Kafaween',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup9cbdqeB (5czbkXrohoRcTv5ZTf9cbD)
                      width: 68*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse8mGw (103:280)
                            left: 0*fem,
                            top: 8*fem,
                            child: Align(
                              child: SizedBox(
                                width: 60*fem,
                                height: 60*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(30*fem),
                                    border: Border.all(color: Color(0xff000000)),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // 1h5 (103:281)
                            left: 12*fem,
                            top: 25*fem,
                            child: Align(
                              child: SizedBox(
                                width: 36*fem,
                                height: 25*fem,
                                child: Text(
                                  '560',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.25*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // star1qAK (103:282)
                            left: 53*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 15*fem,
                                height: 15*fem,
                                child: Image.asset(
                                  'assets/page-1/images/star-1-Mpo.png',
                                  width: 15*fem,
                                  height: 15*fem,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupzfzvA67 (5czbzXTVNtnJ9GtNZ4zfZV)
              left: 187*fem,
              top: 138*fem,
              child: Container(
                width: 166*fem,
                height: 29*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupjuijbBR (5czcFBhjKf4SZwFo2qJuij)
                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 21*fem, 5*fem),
                      width: 36*fem,
                      height: double.infinity,
                      child: Text(
                        'Cancel',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w200,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // autogroup9efdPd5 (5czcNmKS9R3ZZWGz3M9EFD)
                      width: 109*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff2c6367),
                        borderRadius: BorderRadius.circular(5*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          'Save',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // namebUF (103:256)
              left: 40*fem,
              top: 181*fem,
              child: Align(
                child: SizedBox(
                  width: 35*fem,
                  height: 18*fem,
                  child: Text(
                    'Name',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // emailn2w (103:260)
              left: 40*fem,
              top: 263*fem,
              child: Align(
                child: SizedBox(
                  width: 33*fem,
                  height: 18*fem,
                  child: Text(
                    'Email',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // passwordroV (103:263)
              left: 40*fem,
              top: 345*fem,
              child: Align(
                child: SizedBox(
                  width: 58*fem,
                  height: 18*fem,
                  child: Text(
                    'Password',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // newpassword6Sw (103:272)
              left: 40*fem,
              top: 427*fem,
              child: Align(
                child: SizedBox(
                  width: 89*fem,
                  height: 18*fem,
                  child: Text(
                    'New Password',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupdnxmaN7 (5czdSZsnhuY5oqg535dNXm)
              left: 40*fem,
              top: 548*fem,
              child: Container(
                width: 306*fem,
                height: 18*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // gender5Js (103:284)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.25*fem, 0*fem),
                      child: Text(
                        'Gender',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff373e40),
                        ),
                      ),
                    ),
                    Container(
                      // mdigendermalefemalex7m (103:285)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.46*fem),
                      width: 8.13*fem,
                      height: 11.38*fem,
                      child: Image.asset(
                        'assets/page-1/images/mdi-gender-male-female-GD1.png',
                        width: 8.13*fem,
                        height: 11.38*fem,
                      ),
                    ),
                    Container(
                      // autogrouplln7n6o (5czdptZvktR2pV1WSuLLN7)
                      padding: EdgeInsets.fromLTRB(92.63*fem, 0*fem, 0*fem, 0*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // ellipse3eeo (103:277)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 1*fem),
                            width: 13*fem,
                            height: 13*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(6.5*fem),
                              color: Color(0xff2c6367),
                            ),
                          ),
                          Container(
                            // malekC3 (103:278)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                            child: Text(
                              'Male',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // ellipse2F8o (103:276)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 1*fem),
                            width: 13*fem,
                            height: 13*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(6.5*fem),
                              color: Color(0xffefefef),
                            ),
                          ),
                          Text(
                            // female9jy (103:279)
                            'Female',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupnxepsfy (5cze7JGFfHcWhpEHK6NxeP)
              left: 40*fem,
              top: 597*fem,
              child: Container(
                width: 313*fem,
                height: 25*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogrouplgtuvu9 (5czeZY1Y3qQYbrzZ7VLgTu)
                      padding: EdgeInsets.fromLTRB(0*fem, 4*fem, 129.71*fem, 3*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // hospitalscmy (103:297)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.71*fem, 0*fem),
                            child: Text(
                              'Hospitals',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // mdihospitalmarkerbdu (103:295)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            width: 7.58*fem,
                            height: 10.83*fem,
                            child: Image.asset(
                              'assets/page-1/images/mdi-hospital-marker.png',
                              width: 7.58*fem,
                              height: 10.83*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupbzlbHFq (5czePNdoRrMGDVfkV7BzLB)
                      padding: EdgeInsets.fromLTRB(11*fem, 6*fem, 8.39*fem, 5*fem),
                      height: double.infinity,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffefefef)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // kinghamzahomgo (103:301)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.39*fem, 0*fem),
                            child: Text(
                              'King Hamza Ho ..',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 10*ffem,
                                fontWeight: FontWeight.w200,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // materialsymbolsarrowdropdownro (103:299)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.6*fem, 0*fem, 0*fem),
                            width: 7.21*fem,
                            height: 4.6*fem,
                            child: Image.asset(
                              'assets/page-1/images/material-symbols-arrow-drop-down-rounded-6no.png',
                              width: 7.21*fem,
                              height: 4.6*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupzifvsNT (5czepn58yozUBQym44ZifV)
              left: 40*fem,
              top: 653*fem,
              child: Container(
                width: 313*fem,
                height: 25*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupa4fvmyd (5czfaFph7M8otvR4x6A4FV)
                      padding: EdgeInsets.fromLTRB(0*fem, 4*fem, 118.08*fem, 3*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // bloodtypeHh5 (103:302)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.08*fem, 0*fem),
                            child: Text(
                              'Blood Type',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // mdiwatercircleBnT (103:309)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            width: 10.83*fem,
                            height: 10.83*fem,
                            child: Image.asset(
                              'assets/page-1/images/mdi-water-circle-A6f.png',
                              width: 10.83*fem,
                              height: 10.83*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup1n7mF1d (5czfQ6SxVN5XWZ6GKi1N7m)
                      padding: EdgeInsets.fromLTRB(11*fem, 6*fem, 8.39*fem, 5*fem),
                      height: double.infinity,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffefefef)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // oGhR (103:308)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 67.39*fem, 0*fem),
                            child: Text(
                              'O+',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 10*ffem,
                                fontWeight: FontWeight.w200,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // materialsymbolsarrowdropdownro (103:306)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.6*fem, 0*fem, 0*fem),
                            width: 7.21*fem,
                            height: 4.6*fem,
                            child: Image.asset(
                              'assets/page-1/images/material-symbols-arrow-drop-down-rounded-ZxP.png',
                              width: 7.21*fem,
                              height: 4.6*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupz5rvdAb (5czfsAWBiW2PLjJoMYZ5RV)
              left: 40*fem,
              top: 709*fem,
              child: Container(
                width: 313*fem,
                height: 25*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupzrnsLKu (5czgHEeQj7pfp3Vb9nzRNs)
                      padding: EdgeInsets.fromLTRB(0*fem, 4*fem, 160.25*fem, 3*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // city1gw (103:318)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.25*fem, 0*fem),
                            child: Text(
                              'City',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // mdimapmarkercircleVc7 (103:325)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                            width: 12.5*fem,
                            height: 12.5*fem,
                            child: Image.asset(
                              'assets/page-1/images/mdi-map-marker-circle.png',
                              width: 12.5*fem,
                              height: 12.5*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup6vbdz35 (5czg8A5Co6mG93TXXV6vBD)
                      padding: EdgeInsets.fromLTRB(11*fem, 6*fem, 8.39*fem, 5*fem),
                      height: double.infinity,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffefefef)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // azzarqaThM (103:322)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 40.39*fem, 0*fem),
                            child: Text(
                              'AZ Zarqa',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 10*ffem,
                                fontWeight: FontWeight.w200,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // materialsymbolsarrowdropdownro (103:320)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.6*fem, 0*fem, 0*fem),
                            width: 7.21*fem,
                            height: 4.6*fem,
                            child: Image.asset(
                              'assets/page-1/images/material-symbols-arrow-drop-down-rounded.png',
                              width: 7.21*fem,
                              height: 4.6*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupahr5qT1 (5czgW9SZiFBUn31fF8aHR5)
              left: 40*fem,
              top: 767*fem,
              child: Container(
                width: 313*fem,
                height: 22*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // profilepicture6tj (103:329)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 123*fem, 0*fem),
                      child: Text(
                        'Profile Picture',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff373e40),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupx9cpB9V (5czgjUPh7fchi6FrxBx9CP)
                      width: 108*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // uploadi9R (103:332)
                            left: 28*fem,
                            top: 4*fem,
                            child: Align(
                              child: SizedBox(
                                width: 32*fem,
                                height: 14*fem,
                                child: Text(
                                  'Upload',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 10*ffem,
                                    fontWeight: FontWeight.w200,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle20jqD (103:331)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 108*fem,
                                height: 22*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff2c6367)),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // mdiclouduploadoutlineNNP (103:333)
                            left: 67.5416259766*fem,
                            top: 6.1667480469*fem,
                            child: Align(
                              child: SizedBox(
                                width: 11.92*fem,
                                height: 8.67*fem,
                                child: Image.asset(
                                  'assets/page-1/images/mdi-cloud-upload-outline.png',
                                  width: 11.92*fem,
                                  height: 8.67*fem,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupkwixRLf (5czcZgAvKXdzHb7DydKWiX)
              left: 40*fem,
              top: 207*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(14*fem, 9*fem, 14*fem, 9*fem),
                width: 313*fem,
                height: 39*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffefefef)),
                ),
                child: Text(
                  'Osama Kafaween',
                  style: SafeGoogleFont (
                    'Nunito',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w200,
                    height: 1.3625*ffem/fem,
                    color: Color(0xff373e40),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupnatvQiP (5czcnRJgjjmS4kjeDsnaTV)
              left: 40*fem,
              top: 289*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(14*fem, 9*fem, 14*fem, 9*fem),
                width: 313*fem,
                height: 39*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffefefef)),
                ),
                child: Text(
                  'Osama.Kfaween@gmail.com',
                  style: SafeGoogleFont (
                    'Nunito',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w200,
                    height: 1.3625*ffem/fem,
                    color: Color(0xff373e40),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupkrfuRNb (5czcykK9L9SGkuJ1mskrfu)
              left: 40*fem,
              top: 371*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 15*fem, 9*fem),
                width: 313*fem,
                height: 39*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffefefef)),
                ),
                child: Text(
                  'Old Password',
                  style: SafeGoogleFont (
                    'Nunito',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w200,
                    height: 1.3625*ffem/fem,
                    color: Color(0xff373e40),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupzkppem9 (5czdCA88cX6zAR98KwzKpP)
              left: 40*fem,
              top: 453*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 15*fem, 9*fem),
                width: 313*fem,
                height: 39*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffefefef)),
                ),
                child: Text(
                  'New Password',
                  style: SafeGoogleFont (
                    'Nunito',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w200,
                    height: 1.3625*ffem/fem,
                    color: Color(0xff373e40),
                  ),
                ),
              ),
            ),
            Positioned(
              // line11BPh (103:283)
              left: 40*fem,
              top: 522*fem,
              child: Align(
                child: SizedBox(
                  width: 313.03*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffefefef),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line16g5Z (103:330)
              left: 40*fem,
              top: 752*fem,
              child: Align(
                child: SizedBox(
                  width: 313.03*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffefefef),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}