import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signup11ngs (9:6)
        padding: EdgeInsets.fromLTRB(40*fem, 80*fem, 40*fem, 33*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupz1bybeK (5cz5bZmh2B5Tpu5ieMZ1by)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupdeew4H1 (5cz5rj16fh3hp386fPDeew)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                    width: 32*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-deew.png',
                      width: 32*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // autogroupznwf6Ub (5cz5xofJPBxY8B8R46znWF)
                    width: 32*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-znwf.png',
                      width: 32*fem,
                      height: 32*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup2gljMvK (5cz68oNeSFnTKiZZqQ2gLj)
              margin: EdgeInsets.fromLTRB(95*fem, 0*fem, 95*fem, 60*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // rectangle7fw1 (37:375)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 51*fem, 0*fem),
                    width: 36*fem,
                    height: 7*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xff2c6367),
                    ),
                  ),
                  Container(
                    // rectangle8mDM (37:376)
                    width: 36*fem,
                    height: 7*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffefefef),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // registrationg5R (10:14)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 170*fem, 9*fem),
              child: Text(
                'Registration',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // pleaseenteryouremailandphonenu (10:28)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 17*fem),
              child: Text(
                'Please enter your email and phone number',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w300,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // input97R (10:43)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 13*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Full Name',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputrg3 (10:46)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 13*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Email',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputTfq (126:443)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 15*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Password',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputE4K (10:49)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 14*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Confirm passsword',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputbSb (126:446)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 16*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Phone Number',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputbL7 (126:440)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 24*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'User ID',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // buttonYef (10:60)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 26*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 293*fem,
                  height: 50*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff2c6367),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x59000000),
                        offset: Offset(0*fem, 7*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Proceed',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // alreadyhaveaccountloginJ1Z (10:68)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 116*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: RichText(
                  text: TextSpan(
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                    children: [
                      TextSpan(
                        text: 'Already have account ?',
                      ),
                      TextSpan(
                        text: ' Login',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff2c6367),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}