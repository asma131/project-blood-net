import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // adminnotificationKC7 (103:224)
        padding: EdgeInsets.fromLTRB(40*fem, 99*fem, 40*fem, 600*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupruxpy1m (5czZKX5SGurtxxihXURuxP)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 127*fem, 35*fem),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // line83XR (103:228)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 9.73*fem, 0*fem),
                    width: 29.27*fem,
                    height: 2*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                  Container(
                    // notificationsWA7 (103:227)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                    child: Text(
                      'Notifications',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // mdisquareroundedbadgeoutlineyZ (103:229)
                    width: 20*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-square-rounded-badge-outline-AKD.png',
                      width: 20*fem,
                      height: 20*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup5pcfF1D (5czZX6aUihNnSM7Yr75Pcf)
              padding: EdgeInsets.fromLTRB(15*fem, 20*fem, 19*fem, 19*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xffefefef)),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(10*fem),
                  bottomLeft: Radius.circular(10*fem),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupqfabGwu (5czZiqjujQ836ZQ41pqfaB)
                    width: double.infinity,
                    height: 50*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // n1AXV (103:240)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                          width: 50*fem,
                          height: 50*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(57*fem),
                            child: Image.asset(
                              'assets/page-1/images/n-1-oRm.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Container(
                          // autogroupnmt7bMu (5czZsRKwxfVMD5mA6sNmt7)
                          margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 2*fem),
                          width: 217*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // osamahkfaweenacceptedyourreque (103:233)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                                child: Text(
                                  'Osamah Kfaween accepted your request',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroup4hmmZT9 (5czZz5oWfNhxg7PFxQ4hmm)
                                margin: EdgeInsets.fromLTRB(0.01*fem, 0*fem, 126.21*fem, 0*fem),
                                width: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // markasread3dD (103:244)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.25*fem, 0*fem),
                                      child: Text(
                                        'Mark as read',
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w200,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // mdicheckallgw5 (103:242)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.64*fem),
                                      width: 14.53*fem,
                                      height: 8.39*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/mdi-check-all-B31.png',
                                        width: 14.53*fem,
                                        height: 8.39*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // line158HH (103:241)
                    margin: EdgeInsets.fromLTRB(62*fem, 0*fem, 126*fem, 0*fem),
                    width: double.infinity,
                    height: 1*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}