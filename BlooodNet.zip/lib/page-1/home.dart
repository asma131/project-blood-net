import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homehhV (37:429)
        padding: EdgeInsets.fromLTRB(40*fem, 84*fem, 0*fem, 59*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupm5txHvb (5czDufFjWBxbzUN7ygm5tX)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 40*fem, 58*fem),
              width: double.infinity,
              height: 50*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group82nMZ (103:247)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 104*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(57*fem),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // n1dNB (103:246)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                              width: 50*fem,
                              height: 50*fem,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(57*fem),
                                child: Image.asset(
                                  'assets/page-1/images/n-1-nbu.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Container(
                              // osamakafaween4TV (41:436)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                              child: Text(
                                'Osama Kafaween',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff373e40),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // mdibellbadgeKuD (41:439)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 30*fem,
                        height: 30*fem,
                        child: Image.asset(
                          'assets/page-1/images/mdi-bell-badge.png',
                          width: 30*fem,
                          height: 30*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupfjy597Z (5czE99sFUXdC7MVyXqFjy5)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 143*fem, 38*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // line8FAb (41:442)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 10.73*fem, 0*fem),
                    width: 29.27*fem,
                    height: 2*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                  Text(
                    // hospitalsnearyouLC3 (41:441)
                    'Hospitals near you',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame2obR (41:447)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 50*fem),
              width: double.infinity,
              height: 166*fem,
              child: Container(
                // group1vAF (41:446)
                width: 766*fem,
                height: double.infinity,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupvrzqZyu (5czEvt44GTNxr1TbMYvrZq)
                      width: 250*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(15*fem),
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/unsplash-1c8sj2io2i4-bg.png',
                          ),
                        ),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle14E4T (41:462)
                            left: 0*fem,
                            top: 128*fem,
                            child: Align(
                              child: SizedBox(
                                width: 250*fem,
                                height: 26*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xe52c6367),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // thespecialtyhospital6MZ (41:463)
                            left: 15*fem,
                            top: 131*fem,
                            child: Align(
                              child: SizedBox(
                                width: 153*fem,
                                height: 21*fem,
                                child: Text(
                                  'The Specialty Hospital',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 8*fem,
                    ),
                    Container(
                      // autogrouphyum7nT (5czF3o2CpYSd6GvAyiHyuM)
                      width: 250*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(15*fem),
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/unsplash-zbpgmge27p8-bg.png',
                          ),
                        ),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle15yJs (44:464)
                            left: 0*fem,
                            top: 128*fem,
                            child: Align(
                              child: SizedBox(
                                width: 250*fem,
                                height: 26*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xe52c6367),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // hebahospitalcsd (44:465)
                            left: 15*fem,
                            top: 131*fem,
                            child: Align(
                              child: SizedBox(
                                width: 97*fem,
                                height: 21*fem,
                                child: Text(
                                  'Heba Hospital',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 8*fem,
                    ),
                    Container(
                      // autogroup4gomTtF (5czFChw2BeGfaT4akw4gom)
                      width: 250*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(15*fem),
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/unsplash-iqgtaqnk3vm-bg.png',
                          ),
                        ),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // rectangle16Yuh (44:466)
                            left: 0*fem,
                            top: 128*fem,
                            child: Align(
                              child: SizedBox(
                                width: 250*fem,
                                height: 26*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xe52c6367),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // alkhalidihospitalcuZ (44:467)
                            left: 15*fem,
                            top: 131*fem,
                            child: Align(
                              child: SizedBox(
                                width: 127*fem,
                                height: 21*fem,
                                child: Text(
                                  'Al Khalidi Hospital',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              // autogroupcrquk8b (5czEKjPxWoktTnYumwCRqu)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27.43*fem, 16*fem),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // line9eUs (41:449)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 10.73*fem, 0*fem),
                    width: 29.27*fem,
                    height: 2*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff2c6367),
                    ),
                  ),
                  Container(
                    // mostdemandxEf (41:448)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 81*fem, 0*fem),
                    child: Text(
                      'Most demand ',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // seeallFUf (41:455)
                    margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 11*fem, 0*fem),
                    child: Text(
                      'See All',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w300,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // materialsymbolsarrowrightaltro (41:456)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 0*fem),
                    width: 15.57*fem,
                    height: 11.15*fem,
                    child: Image.asset(
                      'assets/page-1/images/material-symbols-arrow-right-alt-rounded.png',
                      width: 15.57*fem,
                      height: 11.15*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame3PUP (44:495)
              width: double.infinity,
              height: 275*fem,
              child: Container(
                // group2VnK (44:494)
                width: 518*fem,
                height: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // cardZGP (44:479)
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                      width: 164*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xffefefef),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // unsplashamnlyot2ziqUo (41:458)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
                            width: 164*fem,
                            height: 135*fem,
                            child: ClipRRect(
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(15*fem),
                                topRight: Radius.circular(15*fem),
                              ),
                              child: Image.asset(
                                'assets/page-1/images/unsplash-amnlyot2zi.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Container(
                            // abdalihospital6fd (44:469)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 6*fem),
                            child: Text(
                              'Abdali Hospital',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // donatorperyearm15 (44:476)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 22*fem),
                            child: Text(
                              '10,500 Donator per year',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 10*ffem,
                                fontWeight: FontWeight.w200,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupsb3zFB9 (5czFgrnn6kDQ7zZrnqsb3Z)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                            width: 102*fem,
                            height: 23*fem,
                            decoration: BoxDecoration (
                              color: Color(0xff2c6367),
                              borderRadius: BorderRadius.circular(5*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Donate',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 13*fem,
                    ),
                    Container(
                      // cardeUB (44:480)
                      width: 164*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xffefefef),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // unsplashdwxetpzjws8XH5 (41:459)
                            width: 164*fem,
                            height: 135*fem,
                            child: ClipRRect(
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(15*fem),
                                topRight: Radius.circular(15*fem),
                              ),
                              child: Image.asset(
                                'assets/page-1/images/unsplash-dwxetpzjws8-ACb.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Container(
                            // autogroupxekjoEb (5czGFm1dC1E3V4xESmXEkj)
                            padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 20*fem, 32*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupaypo5T1 (5czG2MEJW8B8xbmCpAaypo)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
                                  width: double.infinity,
                                  height: 54*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // kingabdullahuniversityhospital (44:483)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 129*fem,
                                            height: 41*fem,
                                            child: Text(
                                              'King Abdullah University Hospital',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 15*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.3625*ffem/fem,
                                                color: Color(0xff373e40),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // donatorperyearNKd (44:485)
                                        left: 0*fem,
                                        top: 40*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 108*fem,
                                            height: 14*fem,
                                            child: Text(
                                              '13,000 Donator per year',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 10*ffem,
                                                fontWeight: FontWeight.w200,
                                                height: 1.3625*ffem/fem,
                                                color: Color(0xff373e40),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroup3k7ybTH (5czG8gP64zw23ybzyX3K7y)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                                  width: 102*fem,
                                  height: 23*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff2c6367),
                                    borderRadius: BorderRadius.circular(5*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Donate',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 13*fem,
                    ),
                    Container(
                      // cardxx3 (44:487)
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 32*fem),
                      width: 164*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xffefefef),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // unsplashb16m5i0tpgoSsD (41:460)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
                            width: 164*fem,
                            height: 135*fem,
                            child: ClipRRect(
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(15*fem),
                                topRight: Radius.circular(15*fem),
                              ),
                              child: Image.asset(
                                'assets/page-1/images/unsplash-b16m5i0tpgo.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Container(
                            // istiklalhospitalX7y (44:489)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 6*fem),
                            child: Text(
                              'Istiklal Hospital',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // donatorperyeararw (44:491)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 22*fem),
                            child: Text(
                              '13,000 Donator per year',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 10*ffem,
                                fontWeight: FontWeight.w200,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupwyrjGzf (5czGfuz3V5e1Yo5rAZWyrj)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                            width: 102*fem,
                            height: 23*fem,
                            decoration: BoxDecoration (
                              color: Color(0xff2c6367),
                              borderRadius: BorderRadius.circular(5*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Donate',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}