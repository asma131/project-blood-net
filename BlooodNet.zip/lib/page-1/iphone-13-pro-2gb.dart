import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1284;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13proWBM (116:1167)
        width: double.infinity,
        height: 872.75*fem,
        child: Stack(
          children: [
            Positioned(
              // iphone13profrontRZD (116:1154)
              left: 0*fem,
              top: 0.25*fem,
              child: Container(
                width: 826*fem,
                height: 872.5*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadow5Ns (116:1155)
                      left: 0*fem,
                      top: 854.75*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-971.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bluenHH (116:1156)
                      left: 384*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 427.5*fem,
                          height: 865*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-2q1.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // maskgroupHzj (116:1162)
                      left: 407.787109375*fem,
                      top: 19.7807006836*fem,
                      child: Align(
                        child: SizedBox(
                          width: 381.21*fem,
                          height: 824.94*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group-8Mh.png',
                            width: 381.21*fem,
                            height: 824.94*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // iphone13probackjbq (116:1163)
              left: 457*fem,
              top: 0*fem,
              child: Container(
                width: 827*fem,
                height: 872.75*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowFKH (116:1164)
                      left: 0*fem,
                      top: 855*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-KL7.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blueYZH (116:1165)
                      left: 399*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 428*fem,
                          height: 865.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-e11.png',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}