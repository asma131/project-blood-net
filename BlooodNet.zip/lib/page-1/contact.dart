import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // contactebD (108:422)
        padding: EdgeInsets.fromLTRB(40*fem, 219*fem, 40*fem, 219*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // bloodnetisheretohelpejd (108:425)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26*fem),
              constraints: BoxConstraints (
                maxWidth: 263*fem,
              ),
              child: Text(
                'BloodNet is here to help ',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 35*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // forhospitalregistrationpleasec (108:426)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 39*fem),
              constraints: BoxConstraints (
                maxWidth: 256*fem,
              ),
              child: Text(
                'For hospital registration please contact us ',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w200,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // autogroupzzkyhLX (5cziL1ZqPV87tmTqbhZZKy)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 92*fem, 13*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // ellipse99yD (108:427)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 1*fem),
                    width: 15*fem,
                    height: 15*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(7.5*fem),
                      color: Color(0xff373e40),
                    ),
                  ),
                  Text(
                    // bloodnetgmailcom3Yo (108:431)
                    'BloodNet@gmail.com',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupf4nxh7Z (5cziUfz4uD77bhmmcHf4nX)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 117*fem, 13*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // ellipse10B2j (108:428)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 1*fem),
                    width: 15*fem,
                    height: 15*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(7.5*fem),
                      color: Color(0xff373e40),
                    ),
                  ),
                  Text(
                    // GZy (108:432)
                    '+546 990221 123',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcbcfyzB (5czicRGAHtKbn6gcTtcBcF)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 58*fem, 45*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // ellipse11Ug3 (108:430)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 1*fem),
                    width: 15*fem,
                    height: 15*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(7.5*fem),
                      color: Color(0xff373e40),
                    ),
                  ),
                  Text(
                    // mainstrno23newyorkaj5 (108:433)
                    'Main Str, no 23, New York',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w200,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkhqvtjm (5czijqDUYj5Maqp9dKKhqV)
              width: 109*fem,
              height: 29*fem,
              decoration: BoxDecoration (
                color: Color(0xff2c6367),
                borderRadius: BorderRadius.circular(5*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Contact Us',
                  style: SafeGoogleFont (
                    'Nunito',
                    fontSize: 12*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.3625*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}