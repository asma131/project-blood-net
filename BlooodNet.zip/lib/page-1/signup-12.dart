import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signup12t9R (37:243)
        padding: EdgeInsets.fromLTRB(40*fem, 80*fem, 40*fem, 65*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupvn6p5Uo (5cz8v45Hper3zzdD6oVN6P)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupgp1vkaw (5cz9DNukr6p3QsF57ygP1V)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 249*fem, 0*fem),
                    width: 32*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-gp1v.png',
                      width: 32*fem,
                      height: 32*fem,
                    ),
                  ),
                  Container(
                    // autogroup77y5Rh5 (5cz9Jxanrr2nAXaRyS77y5)
                    width: 32*fem,
                    height: 32*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-77y5.png',
                      width: 32*fem,
                      height: 32*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcdrdwQX (5cz9Td12Na1msTtMz2CdRd)
              margin: EdgeInsets.fromLTRB(95*fem, 0*fem, 95*fem, 72*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // rectangle73yM (37:250)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 51*fem, 0*fem),
                    width: 36*fem,
                    height: 7*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffefefef),
                    ),
                  ),
                  Container(
                    // rectangle8LhZ (37:251)
                    width: 36*fem,
                    height: 7*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xff2c6367),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // filloutyourinfodRm (37:252)
              margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 0*fem, 9*fem),
              child: Text(
                'Fill out your info',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // pleaseprovideuswithyourdetaile (37:253)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 44*fem),
              constraints: BoxConstraints (
                maxWidth: 240*fem,
              ),
              child: Text(
                'Please provide us with your detailed information.',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w300,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // autogroupk3etdCo (5cz9mSpf6mfrqpBBYTk3ET)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 31*fem),
              height: 21*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // genderKLX (37:379)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.75*fem, 0*fem),
                    child: Text(
                      'Gender',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // mdigendermalefemalec4j (103:287)
                    margin: EdgeInsets.fromLTRB(0*fem, 0.63*fem, 0*fem, 0*fem),
                    width: 9.38*fem,
                    height: 13.13*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-gender-male-female.png',
                      width: 9.38*fem,
                      height: 13.13*fem,
                    ),
                  ),
                  Container(
                    // autogroupt14oGf5 (5czA9mWo9kYorTWcxHT14o)
                    padding: EdgeInsets.fromLTRB(76.88*fem, 0*fem, 0*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // ellipse3vjd (103:275)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                          width: 15*fem,
                          height: 15*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(7.5*fem),
                            color: Color(0xff2c6367),
                          ),
                        ),
                        Container(
                          // maleBvT (37:381)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 31*fem, 0*fem),
                          child: Text(
                            'Male',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // ellipse2SrP (37:382)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                          width: 15*fem,
                          height: 15*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(7.5*fem),
                            color: Color(0xffefefef),
                          ),
                        ),
                        Text(
                          // femaleY8j (37:383)
                          'Female',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line1qtX (37:384)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 39*fem),
              width: 312.01*fem,
              height: 2*fem,
              decoration: BoxDecoration (
                color: Color(0xffefefef),
              ),
            ),
            Container(
              // autogroup3abuLaP (5czAXvYYdpCPgGxQX23Abu)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 32*fem),
              width: double.infinity,
              height: 25*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouphgcs3Du (5czB1AGARsNchH4bPwhgCs)
                    padding: EdgeInsets.fromLTRB(0*fem, 3*fem, 103.25*fem, 1*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // bloodtypeXPy (37:385)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.25*fem, 0*fem),
                          child: Text(
                            'Blood Type',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // mdiwatercirclePBH (103:289)
                          width: 12.5*fem,
                          height: 12.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-water-circle-2wm.png',
                            width: 12.5*fem,
                            height: 12.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupp16jVEK (5czAoLGY8i1gSeqGJgP16j)
                    padding: EdgeInsets.fromLTRB(11*fem, 6*fem, 8.39*fem, 5*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // selectA5Z (37:390)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 54.39*fem, 0*fem),
                          child: Text(
                            'Select',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 10*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // materialsymbolsarrowdropdownro (37:387)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.6*fem, 0*fem, 0*fem),
                          width: 7.21*fem,
                          height: 4.6*fem,
                          child: Image.asset(
                            'assets/page-1/images/material-symbols-arrow-drop-down-rounded-okP.png',
                            width: 7.21*fem,
                            height: 4.6*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line84q9 (76:273)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.99*fem, 47*fem),
              width: 312.01*fem,
              height: 2*fem,
              decoration: BoxDecoration (
                color: Color(0xffefefef),
              ),
            ),
            Container(
              // autogroupburkjAb (5czBGepMDDob44tH79burK)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 35*fem),
              width: double.infinity,
              height: 25*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroup5h6b187 (5czBeeBi8NDoh4SQpo5H6B)
                    padding: EdgeInsets.fromLTRB(0*fem, 3*fem, 154.25*fem, 1*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // cityi2X (37:392)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.25*fem, 0*fem),
                          child: Text(
                            'City',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // mdimapmarkercirclezkj (103:291)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                          width: 12.5*fem,
                          height: 12.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-map-marker-circle-Cnw.png',
                            width: 12.5*fem,
                            height: 12.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupmmnjTeK (5czBWPvT2wKDxBrcRvmmNj)
                    padding: EdgeInsets.fromLTRB(11*fem, 6*fem, 8.39*fem, 5*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // select9GF (37:397)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 54.39*fem, 0*fem),
                          child: Text(
                            'Select',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 10*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // materialsymbolsarrowdropdownro (37:395)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.6*fem, 0*fem, 0*fem),
                          width: 7.21*fem,
                          height: 4.6*fem,
                          child: Image.asset(
                            'assets/page-1/images/material-symbols-arrow-drop-down-rounded-EMR.png',
                            width: 7.21*fem,
                            height: 4.6*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line9RNB (76:274)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.99*fem, 38*fem),
              width: 312.01*fem,
              height: 2*fem,
              decoration: BoxDecoration (
                color: Color(0xffefefef),
              ),
            ),
            Container(
              // autogroup6jymhab (5czBsU9fq2xw4e1ezb6jym)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
              width: double.infinity,
              height: 25*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupesibbvs (5czCJYGEFA9QeuYMsNEsib)
                    padding: EdgeInsets.fromLTRB(0*fem, 3*fem, 120.13*fem, 1*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // hospitalsvCT (37:404)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.13*fem, 0*fem),
                          child: Text(
                            'Hospitals',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // mdihospitalmarkerDST (103:293)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                          width: 8.75*fem,
                          height: 12.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-hospital-marker-RiB.png',
                            width: 8.75*fem,
                            height: 12.5*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouptbkyuaB (5czC8o3U3UAYEbwgrhtBKy)
                    width: 108*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          // materialsymbolsarrowdropdownro (37:407)
                          left: 92.3942871094*fem,
                          top: 10.4000244141*fem,
                          child: Align(
                            child: SizedBox(
                              width: 7.21*fem,
                              height: 4.6*fem,
                              child: Image.asset(
                                'assets/page-1/images/material-symbols-arrow-drop-down-rounded-Com.png',
                                width: 7.21*fem,
                                height: 4.6*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // selectqs9 (37:409)
                          left: 11*fem,
                          top: 6*fem,
                          child: Align(
                            child: SizedBox(
                              width: 27*fem,
                              height: 14*fem,
                              child: Text(
                                'Select',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w200,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // selectEuH (37:418)
                          left: 11*fem,
                          top: 6*fem,
                          child: Align(
                            child: SizedBox(
                              width: 27*fem,
                              height: 14*fem,
                              child: Text(
                                'Select',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 10*ffem,
                                  fontWeight: FontWeight.w200,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupb9akWbu (5czCX7jc6T3VFFH8GXb9AK)
              margin: EdgeInsets.fromLTRB(203*fem, 0*fem, 0*fem, 0*fem),
              width: 108*fem,
              height: 107*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame1mnj (37:427)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 24*fem, 0*fem, 24*fem),
                      width: 108*fem,
                      height: 107*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Align(
                        // line5PJK (37:422)
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          width: double.infinity,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffefefef),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // xJAP (37:420)
                    left: 11*fem,
                    top: 6*fem,
                    child: Align(
                      child: SizedBox(
                        width: 7*fem,
                        height: 14*fem,
                        child: Text(
                          'X',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // yY4j (37:421)
                    left: 11*fem,
                    top: 29*fem,
                    child: Align(
                      child: SizedBox(
                        width: 6*fem,
                        height: 14*fem,
                        child: Text(
                          'Y',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // zpH9 (37:424)
                    left: 11*fem,
                    top: 53*fem,
                    child: Align(
                      child: SizedBox(
                        width: 6*fem,
                        height: 14*fem,
                        child: Text(
                          'Z',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // dG99 (37:425)
                    left: 11*fem,
                    top: 77*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 14*fem,
                        child: Text(
                          'D',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 10*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line69Cw (37:423)
                    left: 0*fem,
                    top: 48*fem,
                    child: Align(
                      child: SizedBox(
                        width: 108*fem,
                        height: 1*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffefefef),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line7RAT (37:426)
                    left: 0*fem,
                    top: 72*fem,
                    child: Align(
                      child: SizedBox(
                        width: 108*fem,
                        height: 1*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffefefef),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}