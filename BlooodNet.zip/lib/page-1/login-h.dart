import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginhV4P (37:257)
        padding: EdgeInsets.fromLTRB(40*fem, 92*fem, 40*fem, 94*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // undrawmedicalcaremovn1LKu (37:264)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 61*fem),
              width: 313*fem,
              height: 232*fem,
              child: Image.asset(
                'assets/page-1/images/undrawmedicalcaremovn-1-1Xq.png',
                width: 313*fem,
                height: 232*fem,
              ),
            ),
            Container(
              // welcomeback3tX (37:258)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 141*fem, 30*fem),
              child: Text(
                'Welcome Back',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // inputTxF (37:261)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 31*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'ID',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // inputbBH (37:262)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 45*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(18*fem, 17*fem, 18*fem, 17*fem),
                  width: 293*fem,
                  decoration: BoxDecoration (
                    color: Color(0xffefefef),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Text(
                    'Password',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // buttonkTV (37:263)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 31*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 293*fem,
                  height: 50*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff2c6367),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x59000000),
                        offset: Offset(0*fem, 7*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Login',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupw8dyTWK (5cz7M1ref6QvVkS755w8dy)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 217*fem, 0*fem),
              width: 96*fem,
              height: 41*fem,
              child: Stack(
                children: [
                  Positioned(
                    // newhospitalcontactusMLo (37:259)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 96*fem,
                        height: 41*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                              children: [
                                TextSpan(
                                  text: 'New hospital?\n',
                                ),
                                TextSpan(
                                  text: 'Contact us',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff2c6367),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // newhospitalcontactus4nw (126:449)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 96*fem,
                        height: 41*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                              children: [
                                TextSpan(
                                  text: 'New hospital?\n',
                                ),
                                TextSpan(
                                  text: 'Contact us',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff2c6367),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}