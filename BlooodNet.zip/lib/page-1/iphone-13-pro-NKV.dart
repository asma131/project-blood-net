import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1284;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13pro9p7 (116:1095)
        width: double.infinity,
        height: 872.75*fem,
        child: Stack(
          children: [
            Positioned(
              // iphone13profrontt11 (116:1082)
              left: 0*fem,
              top: 0.25*fem,
              child: Container(
                width: 826*fem,
                height: 872.5*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowvyH (116:1083)
                      left: 0*fem,
                      top: 854.75*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-pCB.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blueqaT (116:1084)
                      left: 384*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 427.5*fem,
                          height: 865*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-ufH.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // maskgroup9LF (116:1090)
                      left: 407.787109375*fem,
                      top: 19.7807006836*fem,
                      child: Align(
                        child: SizedBox(
                          width: 381.21*fem,
                          height: 824.94*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group-v19.png',
                            width: 381.21*fem,
                            height: 824.94*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // iphone13probackoQo (116:1091)
              left: 457*fem,
              top: 0*fem,
              child: Container(
                width: 827*fem,
                height: 872.75*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowfxo (116:1092)
                      left: 0*fem,
                      top: 855*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-XLf.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blueZ2b (116:1093)
                      left: 399*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 428*fem,
                          height: 865.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-ne7.png',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}