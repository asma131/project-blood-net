import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // unsplashzqH (2:85)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/unsplash-fkc9ewrnlgy-bg.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle2qcw (2:95)
              left: 0*fem,
              top: 435*fem,
              child: Align(
                child: SizedBox(
                  width: 393*fem,
                  height: 417*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x89305252),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // blooddonationhasntbeeneasierMz (2:87)
              left: 40*fem,
              top: 491*fem,
              child: Align(
                child: SizedBox(
                  width: 304*fem,
                  height: 96*fem,
                  child: Text(
                    'Blood donation hasn’t been easier ',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 35*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ourapphelpsyoufindthenearestho (2:88)
              left: 40*fem,
              top: 617*fem,
              child: Align(
                child: SizedBox(
                  width: 311*fem,
                  height: 55*fem,
                  child: Text(
                    'Our app helps you find the nearest hospital.',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // buttonqwh (2:129)
              left: 40*fem,
              top: 716*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 144*fem,
                  height: 50*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff2c6367),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x59000000),
                        offset: Offset(0*fem, 7*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Signup',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // buttonZej (2:155)
              left: 209*fem,
              top: 716*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 144*fem,
                  height: 51*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xffffffff)),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x59000000),
                        offset: Offset(0*fem, 7*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Login',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}