import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // logintypeaLj (111:422)
        padding: EdgeInsets.fromLTRB(45*fem, 149*fem, 44*fem, 112*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // typeofaccount1gw (111:423)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 9*fem),
              child: Text(
                'Type of Account',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // chooseyouraccounttypepleasebec (111:424)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 28*fem),
              constraints: BoxConstraints (
                maxWidth: 291*fem,
              ),
              child: Text(
                'Choose your account type, please be careful while choosing, you can’t change it later.',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w300,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // accounttypeNSw (111:425)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 44*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(58*fem, 17*fem, 58*fem, 16*fem),
                  width: double.infinity,
                  height: 225*fem,
                  decoration: BoxDecoration (
                    borderRadius: BorderRadius.circular(20*fem),
                  ),
                  child: Container(
                    // accounttypemV5 (I111:425;18:1015)
                    padding: EdgeInsets.fromLTRB(0.08*fem, 0*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // undrawmedicineb1ol1g6F (I111:425;18:1016)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                          width: 187.92*fem,
                          height: 133*fem,
                          child: Image.asset(
                            'assets/page-1/images/undrawmedicineb-1-ol-1.png',
                            width: 187.92*fem,
                            height: 133*fem,
                          ),
                        ),
                        Container(
                          // hospitalaccountCMR (I111:425;18:1182)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.08*fem, 0*fem),
                          child: Text(
                            'Hospital Account',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 17*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            TextButton(
              // donatoraccountfF1 (111:426)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(58*fem, 13.97*fem, 58*fem, 13*fem),
                width: double.infinity,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff2c6367)),
                  borderRadius: BorderRadius.circular(20*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // undrawpeoplere8spw1Uy9 (I111:426;18:2707)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                      width: 188*fem,
                      height: 133.03*fem,
                      child: Image.asset(
                        'assets/page-1/images/undrawpeoplere8spw-1-KWj.png',
                        width: 188*fem,
                        height: 133.03*fem,
                      ),
                    ),
                    Container(
                      // donatoraccounttX5 (I111:426;18:2738)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                      child: Text(
                        'Donor Account',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 17*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}