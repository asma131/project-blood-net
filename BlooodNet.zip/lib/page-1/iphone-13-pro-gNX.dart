import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1284;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone13pro4yq (116:1005)
        width: double.infinity,
        height: 872.75*fem,
        child: Stack(
          children: [
            Positioned(
              // iphone13profrontC4T (116:992)
              left: 0*fem,
              top: 0.25*fem,
              child: Container(
                width: 826*fem,
                height: 872.5*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowVpF (116:993)
                      left: 0*fem,
                      top: 854.75*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-zo5.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bluevuZ (116:994)
                      left: 384*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 427.5*fem,
                          height: 865*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-nwd.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // maskgroupSd1 (116:1000)
                      left: 407.787109375*fem,
                      top: 19.7807617188*fem,
                      child: Align(
                        child: SizedBox(
                          width: 381.21*fem,
                          height: 824.94*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group-Yju.png',
                            width: 381.21*fem,
                            height: 824.94*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // iphone13probackW75 (116:1001)
              left: 457*fem,
              top: 0*fem,
              child: Container(
                width: 827*fem,
                height: 872.75*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // shadowors (116:1002)
                      left: 0*fem,
                      top: 855*fem,
                      child: Align(
                        child: SizedBox(
                          width: 826*fem,
                          height: 17.75*fem,
                          child: Image.asset(
                            'assets/page-1/images/shadow-Enf.png',
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // blue7Mm (116:1003)
                      left: 399*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 428*fem,
                          height: 865.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/blue-r1R.png',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}