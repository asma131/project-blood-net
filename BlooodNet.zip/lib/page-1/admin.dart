import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // admin1nK (72:222)
        padding: EdgeInsets.fromLTRB(32*fem, 93*fem, 39*fem, 58*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupxomugNf (5czHcZ5fe7DpmdBsmVxoMu)
              margin: EdgeInsets.fromLTRB(59*fem, 0*fem, 51*fem, 39*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // mdiaccountstarBKR (73:223)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 1*fem),
                    width: 22*fem,
                    height: 16*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-account-star-ZmM.png',
                      width: 22*fem,
                      height: 16*fem,
                    ),
                  ),
                  Container(
                    // abdalihospitalzw5 (73:225)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 15.67*fem, 0*fem),
                    child: Text(
                      'Abdali Hospital',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // mditrianglesmallup275 (73:226)
                    margin: EdgeInsets.fromLTRB(0*fem, 4.17*fem, 22.67*fem, 0*fem),
                    width: 6.67*fem,
                    height: 5.83*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-triangle-small-up.png',
                      width: 6.67*fem,
                      height: 5.83*fem,
                    ),
                  ),
                  Container(
                    // mdibellbadgeEyq (89:222)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/mdi-bell-badge-B95.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupnzvvUNP (5czJ13SCG1L8y6Qy2QnZVV)
              margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 42*fem, 77*fem),
              width: double.infinity,
              height: 21*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupxyckyK9 (5czJMHMUDWq29R7kMdXYcK)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 87*fem, 0*fem),
                    width: 96*fem,
                    height: double.infinity,
                    child: Center(
                      child: Text(
                        'Hospital Stats',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff373e40),
                        ),
                      ),
                    ),
                  ),
                  TextButton(
                    // group78b5d (76:263)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.25*fem, 0*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // requestHUF (73:237)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.75*fem, 0*fem),
                            child: Text(
                              'Request ',
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff373e40),
                              ),
                            ),
                          ),
                          Container(
                            // mdiwaterplusXdV (73:240)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.78*fem, 0*fem, 0*fem),
                            width: 10*fem,
                            height: 11.72*fem,
                            child: Image.asset(
                              'assets/page-1/images/mdi-water-plus-9ko.png',
                              width: 10*fem,
                              height: 11.72*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupewxt1Yf (5czJimjfRuZ9DvzvY1eWxT)
              margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 58*fem),
              width: double.infinity,
              height: 182*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupcfis7rb (5czK8BELArRxwwd6wucfis)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(15*fem, 20*fem, 19*fem, 0*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffefefef),
                      borderRadius: BorderRadius.circular(10*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroup498fh47 (5czKLAtM2w2GPPk5tG498F)
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // totalvisitorsa7u (73:245)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 13*fem),
                                child: Text(
                                  'Total Visitors',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                              Container(
                                // k3XH (73:246)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 53*fem),
                                child: Text(
                                  '1.6K+',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff373e40),
                                  ),
                                ),
                              ),
                              Container(
                                // rectangle229KR (73:249)
                                width: 8*fem,
                                height: 44*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                  borderRadius: BorderRadius.only (
                                    topLeft: Radius.circular(10*fem),
                                    topRight: Radius.circular(10*fem),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle21oPy (73:248)
                          width: 8*fem,
                          height: 77*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff2c6367),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(10*fem),
                              topRight: Radius.circular(10*fem),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle20zzF (73:247)
                          width: 8*fem,
                          height: 98*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff373e40),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(10*fem),
                              topRight: Radius.circular(10*fem),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupwwpohtf (5czKeVh9TtNSvDhryxwwpo)
                    padding: EdgeInsets.fromLTRB(5*fem, 20*fem, 5*fem, 6*fem),
                    width: 147*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffefefef),
                      borderRadius: BorderRadius.circular(10*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // totaldonationkc3 (73:251)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 13*fem),
                          child: Text(
                            'Total Donation',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupk5akrQB (5czKmQfJ1yS7AVASc8K5AK)
                          width: double.infinity,
                          height: 126*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // kBhM (73:252)
                                left: 10*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 67*fem,
                                    height: 35*fem,
                                    child: Text(
                                      '2.4K+',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xff373e40),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // graphlinesD8F (73:259)
                                left: 0*fem,
                                top: 25*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 137*fem,
                                    height: 101*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/graph-lines.png',
                                      width: 137*fem,
                                      height: 101*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupzk9yToH (5czLJE7H1m4ghEvABSzk9y)
              width: double.infinity,
              height: 299*fem,
              child: Stack(
                children: [
                  Positioned(
                    // ellipse8moy (74:300)
                    left: 220.0000610352*fem,
                    top: 239*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 60*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(30*fem),
                            border: Border.all(color: Color(0xff000000)),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle243mV (74:270)
                    left: 8.0000610352*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 147*fem,
                        height: 182*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xffefefef),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle28uYo (74:276)
                    left: 175.0000610352*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 147*fem,
                        height: 182*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(10*fem),
                            color: Color(0xffefefef),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group77r6f (74:293)
                    left: 207.840637207*fem,
                    top: 89*fem,
                    child: Container(
                      width: 84.16*fem,
                      height: 84.16*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(7.6015119553*fem),
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/ellipse-6.png',
                          ),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          '30%',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 0.7601511955*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // mostrequestedQnP (74:271)
                    left: 23.0000610352*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 88*fem,
                        height: 17*fem,
                        child: Text(
                          'Most Requested',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // onlinevisitorsd9M (74:277)
                    left: 190.0000610352*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 17*fem,
                        child: Text(
                          'Online Visitors',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // oeq9 (74:272)
                    left: 23.0000610352*fem,
                    top: 50*fem,
                    child: Align(
                      child: SizedBox(
                        width: 35*fem,
                        height: 35*fem,
                        child: Text(
                          'O+',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // J91 (74:278)
                    left: 190.0000610352*fem,
                    top: 50*fem,
                    child: Align(
                      child: SizedBox(
                        width: 60*fem,
                        height: 35*fem,
                        child: Text(
                          '480+',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group769fR (74:287)
                    left: 0*fem,
                    top: 78*fem,
                    child: Container(
                      width: 164*fem,
                      height: 164*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(10*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse5SeX (74:288)
                            left: 15.0473937988*fem,
                            top: 15.0473632812*fem,
                            child: Align(
                              child: SizedBox(
                                width: 133.91*fem,
                                height: 133.91*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-5.png',
                                  width: 133.91*fem,
                                  height: 133.91*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse4Vsh (74:289)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 164*fem,
                                height: 164*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-4.png',
                                  width: 164*fem,
                                  height: 164*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // labelBEj (74:290)
                            left: 50.5000610352*fem,
                            top: 51.5*fem,
                            child: Center(
                              child: Align(
                                child: SizedBox(
                                  width: 63*fem,
                                  height: 25*fem,
                                  child: Text(
                                    '29.9k+',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.25*ffem/fem,
                                      color: Color(0xff373e40),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // hospitalpointsAcT (74:297)
                    left: 45.0000610352*fem,
                    top: 256*fem,
                    child: Align(
                      child: SizedBox(
                        width: 137*fem,
                        height: 25*fem,
                        child: Text(
                          'Hospital Points',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.25*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line8qCo (74:298)
                    left: 8.0000610352*fem,
                    top: 271*fem,
                    child: Align(
                      child: SizedBox(
                        width: 29.27*fem,
                        height: 2*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff2c6367),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // 45Z (74:299)
                    left: 232.0000610352*fem,
                    top: 256*fem,
                    child: Align(
                      child: SizedBox(
                        width: 36*fem,
                        height: 25*fem,
                        child: Text(
                          '420',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.25*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // star1XUw (74:301)
                    left: 273.0000610352*fem,
                    top: 231*fem,
                    child: Align(
                      child: SizedBox(
                        width: 15*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/star-1.png',
                          width: 15*fem,
                          height: 15*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}