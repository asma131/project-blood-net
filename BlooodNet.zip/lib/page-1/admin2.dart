import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // admin2H3y (76:222)
        padding: EdgeInsets.fromLTRB(40*fem, 93*fem, 39.97*fem, 69*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupjs5vCq9 (5czNNfebMJfneDnw6Ejs5V)
              margin: EdgeInsets.fromLTRB(51*fem, 0*fem, 50.03*fem, 39*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // mdiaccountstarh1D (89:224)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 1*fem),
                    width: 22*fem,
                    height: 16*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-account-star.png',
                      width: 22*fem,
                      height: 16*fem,
                    ),
                  ),
                  Container(
                    // abdalihospitaltrP (89:226)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 15.67*fem, 0*fem),
                    child: Text(
                      'Abdali Hospital',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Container(
                    // mditrianglesmallupXuM (89:227)
                    margin: EdgeInsets.fromLTRB(0*fem, 4.17*fem, 22.67*fem, 0*fem),
                    width: 6.67*fem,
                    height: 5.83*fem,
                    child: Image.asset(
                      'assets/page-1/images/mdi-triangle-small-up-kMy.png',
                      width: 6.67*fem,
                      height: 5.83*fem,
                    ),
                  ),
                  Container(
                    // mdibellbadgeDGP (89:229)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/mdi-bell-badge-QbD.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupku5hRtF (5czNhA7nMBFLMseN32kU5H)
              margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 42.03*fem, 55*fem),
              width: double.infinity,
              height: 21*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // hospitalstatsiMZ (76:229)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 87*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Text(
                        'Hospital Stats',
                        style: SafeGoogleFont (
                          'Nunito',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3625*ffem/fem,
                          color: Color(0xff373e40),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupshtqBF9 (5czNy4pwYpkigjCBMxShTq)
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.25*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          // requestH3H (76:230)
                          'Request ',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff373e40),
                          ),
                        ),
                        Container(
                          // mdiwaterpluszTV (76:231)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.78*fem, 0*fem, 0*fem),
                          width: 10*fem,
                          height: 11.72*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-water-plus.png',
                            width: 10*fem,
                            height: 11.72*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // title5E3 (76:268)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 276.03*fem, 7*fem),
              child: Text(
                'Title',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // autogroupraxd8i7 (5czPAK1CrmosnToizQraXd)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.03*fem, 39*fem),
              padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 15*fem, 9*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xffefefef)),
              ),
              child: Text(
                'Write a request title',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w200,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // descriptionWCs (76:271)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 221.03*fem, 7*fem),
              child: Text(
                'Description',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // autogroupqrefCLb (5czPNUKcHmdYQjpMmrQrEF)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.03*fem, 40*fem),
              padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 15*fem, 9*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xffefefef)),
              ),
              child: Text(
                'Write a short description',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w200,
                  height: 1.3625*ffem/fem,
                  color: Color(0xff373e40),
                ),
              ),
            ),
            Container(
              // line11QSf (76:272)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 41*fem),
              width: double.infinity,
              height: 2*fem,
              decoration: BoxDecoration (
                color: Color(0xffefefef),
              ),
            ),
            Container(
              // autogroup4ktxvA7 (5czPa3pejZ9Rt8DD6V4KtX)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32.03*fem, 15*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // requesttypeRsZ (76:275)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 69*fem, 0*fem),
                    child: Text(
                      'Request Type',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Text(
                    // initialstatus8X5 (76:276)
                    'Initial Status',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupaznsn5q (5czPq8Ds6cVzGrJmByAZns)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.03*fem, 39*fem),
              width: double.infinity,
              height: 39*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupakqf5qd (5czQEStLZ6m8QSz7gKaKQf)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(13.5*fem, 10*fem, 18.39*fem, 8*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // mdifiledocumentLmZ (76:289)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.5*fem, 2*fem),
                          width: 10*fem,
                          height: 12.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-file-document.png',
                            width: 10*fem,
                            height: 12.5*fem,
                          ),
                        ),
                        Container(
                          // requestdEs (76:278)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55.39*fem, 0*fem),
                          child: Text(
                            'Request',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupfpmr68T (5czQPwcWuQtx3WkJvMFpMR)
                          width: 7.21*fem,
                          height: 12.2*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-fpmr.png',
                            width: 7.21*fem,
                            height: 12.2*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupnvcfzUj (5czQcBm7csLJGChmdLNVCf)
                    padding: EdgeInsets.fromLTRB(7.63*fem, 10*fem, 19.39*fem, 8*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // mdialertdecagramRpw (76:292)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.63*fem, 1.99*fem),
                          width: 13.75*fem,
                          height: 13.08*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-alert-decagram.png',
                            width: 13.75*fem,
                            height: 13.08*fem,
                          ),
                        ),
                        Container(
                          // newrfM (76:284)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47.39*fem, 0*fem),
                          child: Text(
                            'New',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupzoufkVq (5czQkBXnrvPqDqT6FZzoUF)
                          width: 7.21*fem,
                          height: 12.2*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-zouf.png',
                            width: 7.21*fem,
                            height: 12.2*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouprhxqQqH (5czRFvBFAk2Y3Dv4ppRHXq)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42.03*fem, 15*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // cityjMm (76:294)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 147*fem, 0*fem),
                    child: Text(
                      'City',
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff373e40),
                      ),
                    ),
                  ),
                  Text(
                    // bloodtypePx7 (76:306)
                    'Blood Type',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3625*ffem/fem,
                      color: Color(0xff373e40),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupm82fvSF (5czRXKuEfdqpobnvcUm82f)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.03*fem, 42*fem),
              width: double.infinity,
              height: 39*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupi7qp2EP (5czRs9fYCrGJ1rmaKyi7QP)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(14*fem, 10*fem, 18.39*fem, 8*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // ellipse1h5d (37:380)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 1*fem),
                          width: 10*fem,
                          height: 10*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(5*fem),
                            color: Color(0xff2c6367),
                          ),
                        ),
                        Container(
                          // ammanzKd (76:296)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57.39*fem, 0*fem),
                          child: Text(
                            'Amman',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup3dtrgy9 (5czS29QYrQi26Srp2k3DTR)
                          width: 7.21*fem,
                          height: 12.2*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-3dtr.png',
                            width: 7.21*fem,
                            height: 12.2*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupugroXym (5czSE94ZiVJKXtyny6Ugro)
                    padding: EdgeInsets.fromLTRB(8.25*fem, 10*fem, 19.39*fem, 8*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffefefef)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // mdiwatercircleAG3 (76:313)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7.25*fem, 2*fem),
                          width: 12.5*fem,
                          height: 12.5*fem,
                          child: Image.asset(
                            'assets/page-1/images/mdi-water-circle.png',
                            width: 12.5*fem,
                            height: 12.5*fem,
                          ),
                        ),
                        Container(
                          // aFoH (76:305)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 59.39*fem, 0*fem),
                          child: Text(
                            'A+',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w200,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff373e40),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupkcef9tf (5czSMdr5Fnfkw44A44kcEf)
                          width: 7.21*fem,
                          height: 12.2*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-kcef.png',
                            width: 7.21*fem,
                            height: 12.2*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // line12GCb (76:315)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              height: 2*fem,
              decoration: BoxDecoration (
                color: Color(0xffefefef),
              ),
            ),
            Container(
              // autogroupp6z9BKZ (5czSrxLZ9KE3nNo11bP6Z9)
              margin: EdgeInsets.fromLTRB(203.97*fem, 0*fem, 0*fem, 0*fem),
              width: 109*fem,
              height: 29*fem,
              decoration: BoxDecoration (
                color: Color(0xff2c6367),
                borderRadius: BorderRadius.circular(5*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Create Request',
                  style: SafeGoogleFont (
                    'Nunito',
                    fontSize: 13*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.3625*ffem/fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}