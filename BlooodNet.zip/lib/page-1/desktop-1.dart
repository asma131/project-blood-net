import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1440;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // desktop1Pqu (308:433)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 89*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroup8xttF7R (5czoqBjLove1Won5Ck8xtT)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 96*fem),
              height: 131*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupxfcfWZ9 (5czp1gRrZkA2GptBXJXFcf)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 688*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(191*fem, 62*fem, 10*fem, 44*fem),
                    width: 292*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      image: DecorationImage (
                        image: AssetImage (
                          'assets/page-1/images/download-1-bg.png',
                        ),
                      ),
                    ),
                    child: Text(
                      'BloodNet',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff2c6367),
                      ),
                    ),
                  ),
                  Container(
                    // homeeom (312:431)
                    margin: EdgeInsets.fromLTRB(0*fem, 18*fem, 96*fem, 0*fem),
                    child: Text(
                      'Home',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // loginLwV (312:432)
                    margin: EdgeInsets.fromLTRB(0*fem, 18*fem, 71*fem, 0*fem),
                    child: Text(
                      'Login',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // buttonSjd (313:438)
                    margin: EdgeInsets.fromLTRB(0*fem, 48*fem, 0*fem, 30*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 168*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xff2c6367),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x59000000),
                              offset: Offset(0*fem, 7*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            ' Signup',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupvxq5PYP (5czpD1SKA9prxySZ5JVXq5)
              margin: EdgeInsets.fromLTRB(35*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 708*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroup5ppbT2T (5czpP5yrVgGTkvpXn95ppB)
                    margin: EdgeInsets.fromLTRB(0*fem, 68*fem, 26*fem, 162*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // blooddonationhasntbeeneasier8P (313:434)
                          margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 67*fem),
                          constraints: BoxConstraints (
                            maxWidth: 553*fem,
                          ),
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 64*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff000000),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Blood',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 64*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xff2c6367),
                                  ),
                                ),
                                TextSpan(
                                  text: ' donation hasn’t been easier. ',
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // ourapphelpsyoufindthenearestho (313:435)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 91*fem),
                          constraints: BoxConstraints (
                            maxWidth: 497*fem,
                          ),
                          child: Text(
                            'Our app helps you find the nearest hospital.',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 32*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        TextButton(
                          // button5EB (313:436)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 223*fem,
                            height: 57*fem,
                            decoration: BoxDecoration (
                              color: Color(0xff2c6367),
                              borderRadius: BorderRadius.circular(10*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x59000000),
                                  offset: Offset(0*fem, 7*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                '    Find more',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouphi8sTkX (5czpZv19PLFCtbhwnshi8s)
                    width: 1033*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // unsplash7jjnjqa9fyo3h (312:434)
                          left: 0*fem,
                          top: 4*fem,
                          child: Align(
                            child: SizedBox(
                              width: 1033*fem,
                              height: 704*fem,
                              child: Image.asset(
                                'assets/page-1/images/unsplash-7jjnj-qa9fy.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // rectangle41Ba3 (312:435)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 824*fem,
                              height: 708*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0x752c6367),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}